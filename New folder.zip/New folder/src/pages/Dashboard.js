import React from "react";

const Dashboard = () => {
  return (
    <div className="flex justify-center items-center text-white text-3xl h-full">
      Step into Success: Your Journey Begins Here at the Virtual Mentorship Hub!
    </div>
  );
};

export default Dashboard;
